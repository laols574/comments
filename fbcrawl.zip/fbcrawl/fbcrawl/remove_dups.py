import pandas as pd
df = pd.read_csv('./trump_test20.csv')
df2 = df[df.duplicated() == False]
df2.to_csv('./trump_test20.csv',index=False)
