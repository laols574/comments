import pandas as pd
df = pd.read_csv('./trump_comments2.csv')
df2 = df[df.duplicated() == False]
df2.to_csv('./trump_comments2.csv',index=False)
